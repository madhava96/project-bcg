"""hotel URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from star5 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.loginpage,name="loginpage"),
    path('Manager',views.Managerhomepage,name='Managerhomepage'),
    path('Admin',views.Adminhomepage,name='Adminhomepage'),
    path('Receptionist',views.Receptionisthomepage,name='Receptionisthomepage'),
    path('table',views.table,name='table'),
    path('employeedata',views.employeedata,name='employeedata'),
    path('hotelmanager',views.hotelmanager,name='hotelmanager'),
    path('employeeform',views.employeeform,name='employeeform'),
    path('empdetails',views.empdetails,name='details'),
    path('book',views.book, name='book'),
    path('check',views.check, name='check'),
    path('show',views.show,name='show'),
]

    
